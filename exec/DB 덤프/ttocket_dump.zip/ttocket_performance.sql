-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: 3.38.250.25    Database: ttocket
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `performance`
--

DROP TABLE IF EXISTS `performance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `performance` (
  `performance_id` int NOT NULL AUTO_INCREMENT,
  `performance_desc` varchar(255) DEFAULT NULL,
  `performance_end_time` datetime DEFAULT NULL,
  `performance_etc` varchar(255) DEFAULT NULL,
  `performance_location` varchar(255) DEFAULT NULL,
  `performance_max_seats` int DEFAULT NULL,
  `performance_poster` varchar(255) DEFAULT NULL,
  `performance_price` double DEFAULT NULL,
  `performance_start_time` datetime DEFAULT NULL,
  `performance_title` varchar(255) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`performance_id`),
  KEY `FKmp0n6p508qriwusmhnwaqg49q` (`user_id`),
  CONSTRAINT `FKmp0n6p508qriwusmhnwaqg49q` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `performance`
--

LOCK TABLES `performance` WRITE;
/*!40000 ALTER TABLE `performance` DISABLE KEYS */;
INSERT INTO `performance` VALUES (1,'검정치마 3집 part.3 발매기념 클럽 공연을 한다.','2023-04-09 20:00:00','보냅니다...','홍대 왓챠홀',40,'QmNenpu2DeWPRnGszg2ow13wBHuAf2atTUWnQaDXZMRtoC',0.002,'2023-04-08 17:00:00','검정치마 클럽 공연 - TEEN TROUBLES in SEOUL','0x5248E71ec4A6cdE490000f4356b67b6f90aa62B8'),(2,'머리 위로 꽃잎이 떨어지는 계절 4월, 보랏빛 설렘을 안고 봄날에 안착한 볼빨간사춘기가 사랑.zip으로 여러분을 초대합니다.','2023-04-30 13:00:00','보냅니다...',' 올림픽공원 올림픽홀',24,'QmWJN7X2YebQ47PmaEjoSVNFJe9tAMRsDjJySc31V53oqb',0.03,'2023-04-29 18:00:00','2023 볼빨간사춘기 단독 콘서트 \'사랑.zip\'','0xc228f2C7493e6eF3701bF6BAA6FB9643Dac5c5d5'),(3,'합법적인 멍청이들 리짓군즈가 돌아왔다, 미친듯이 뛰어놀고 싶은 사람 모여라!! ','2023-04-08 20:00:00','보냅니다...','상상마당',48,'QmYKJpMGHmWGEXAKBC3579XAZFUBg36UEV8pcTaPyzaVVv',0.001,'2023-04-03 16:00:00','리짓군즈 콘서트','0x5248E71ec4A6cdE490000f4356b67b6f90aa62B8'),(4,'소셜미디어와 스마트폰의 의존도 만큼 사라져가는 사람들의 상상력 R-VD (Realization-Vivid*Dream) 생생하게 꿈꾸면 이루어진다는 꿈을 현실로 만드는 마법 주문입니다. 상상하는 법을 점점 잊고 살아가는 당신에게 비밀스럽게 숨겨진 공간에서 특별한 주문을 걸어드립니다.','2023-04-07 17:30:00','보냅니다...','메가박스 송도',8,'QmPXyGS1f6PC8oTWrTSzgqhkzD3fdT5Qf8icNjvo9mkYpr',0.03,'2023-04-03 16:00:00','폼미쳤다','0xe1CBC454A1f511Ece02ACb690b534310c5C8c1A8'),(5,'당신의 영혼을 걸고 내기를 할까요? 독일 문학의 거장 \'볼프강 폰 괴테\'가 무려 60년을 쏟아 집대성한 필생의 역작을 무대에서 감상해보세요!','2023-04-15 15:00:00','보냅니다...','LG아트센터 서울 LG SIGNATURE 홀',16,'QmSwQexWt8TnMwFnFG3Lqwsm1bY7pM4TAw5nHBJNdEENRR',0.04,'2023-04-10 14:00:00','연극 <파우스트>','0xc228f2C7493e6eF3701bF6BAA6FB9643Dac5c5d5'),(6,'국민가수 임영웅의 미국 콘서트!','2023-04-15 13:30:00','보냅니다...','DOLBY THEATRE',48,'QmPcxXrMoDuHw91QrXoHTMZYNBuRtfWQdLKkdjJsUwHXFJ',0.05,'2023-04-08 13:30:00','임영웅 콘서트 [IM HERO] in Los Angeles','0xe1CBC454A1f511Ece02ACb690b534310c5C8c1A8'),(7,'일리에너 엠비션 US tour의 세 번째 순서. 미국에서도 인정받은 그들의 콘서트가 계속된다.','2023-04-07 20:00:00','보냅니다...','NEUMOS',40,'QmX2YSdbm3bwsApkyoJird8PbxiXsmye7q3HZC5fyXymsn',0.01,'2023-04-02 16:00:00','일리네어 엠비션 합동 콘서트','0x5248E71ec4A6cdE490000f4356b67b6f90aa62B8'),(8,'블랙핑크가 메타버스 세상에서 콘서트를 연다. 꼭 참여하고 싶다.','2023-04-22 19:00:00','보냅니다...','메타버스',48,'QmXZuwsG8zykykdeLThU9JyhrcdgSWMLpGieeLAGzDE2ag',0.005,'2023-04-07 18:00:00','블랙핑크 버츄얼 콘서트','0x5248E71ec4A6cdE490000f4356b67b6f90aa62B8'),(9,'2023 성시경 팬미팅 \" 사월 \" 에 여러분을 초대합니다.','2023-04-08 18:00:00','보냅니다...','장충체육관',16,'Qmdd3X2uAS62Y3CaM8FF9r1N5yxJtszbmertFuZAeYK2Fj',0.02,'2023-04-05 13:00:00','2023 성시경 팬미팅 ＂사월＂','0xc228f2C7493e6eF3701bF6BAA6FB9643Dac5c5d5'),(10,'인간의 모순과, 내면의 혼돈, 영혼의 갈증으로부터 완벽하게 자유로운 이가 있는가. 네 형제와 아버지, 그리고 인간의 내면과 외면 어디에나 존재하는 악마로 재구성된 뮤지컬 브라더스 까라마조프','2023-04-08 17:00:00','보냅니다...','예스24스테이지 1관',16,'QmQZAghuZa6sQ8FKxJL1iwARLDL5iB1NMApJUvLRXdc6DQ',0.345,'2023-04-06 13:45:00','브라더스 까라마조프','0xe1CBC454A1f511Ece02ACb690b534310c5C8c1A8'),(11,'김동률 \"오래된 노래\" 앨범 발매 기념 콘서트 ','2023-04-14 20:30:00','보냅니다...','세종문화회관',32,'QmNqEbCE728GuUKP1zTwFVtm6ozFgQxVCruZkN9tMMoWqX',0.04,'2023-03-31 19:00:00','오래된 노래 - 김동률','0x5248E71ec4A6cdE490000f4356b67b6f90aa62B8'),(12,'오래되었지만 오래되지 않은 김동률의 노래','2019-10-17 14:00:00','보냅니다...','세종문화회관 대극장',8,'QmZNxtWdUa2U9hy4RrBvWvZrgjhA3RcUaQTzsmSMWVCpLK',0.044,'2019-07-05 14:00:00','2019 김동률 콘서트 오래된 노래','0xe1CBC454A1f511Ece02ACb690b534310c5C8c1A8'),(13,'드디어 화해한 갤러거 형제! 노엘과 리암이 한 무대에 등장한다.','2023-04-05 14:06:03','보냅니다...','LONDON',40,'QmWi33E24xfaBfrHoM1XDjZz3GC6oGMW6y1vz2BK14hbRd',0.07,'2023-04-05 14:06:03','Oasis!! Oasis!! Oasis!! Oasis!! Oasis!! ','0x5248E71ec4A6cdE490000f4356b67b6f90aa62B8'),(14,'13년 간의 긴 기다림… 마침내 한국의 유령이 온다! 환영과도 같은 무대 사라지지 않을 영원한 당신의 첫 감동! 13년 만에 오페라 하우스의 문이 열린다','2023-05-12 14:15:04','보냅니다...','드림씨어터',32,'QmWNRTCyA6tkpWzxu5Bd65sTTnY6ghMztcYy2fHxayMtKQ',0.002,'2023-04-08 14:15:04','오페라의 유령','0xe1CBC454A1f511Ece02ACb690b534310c5C8c1A8'),(15,'커트 코베인의 부활... 당장 미국행 비행기 티켓을 끊도록 하자.','2023-04-06 18:30:00','보냅니다...','NEW YORK',40,'QmeZ4sCeWizrcK844RELvc4ASxajQomvsrQpYwC373iSfi',0.003,'2023-04-03 19:00:00','너바나 부활 콘서트','0x5248E71ec4A6cdE490000f4356b67b6f90aa62B8'),(16,'불의의 사고로 아내 레베카를 잃고 힘든 나날을 보내고 있는 막심 드 윈터, 그는 몬테카를로 여행 중 우연히 \'나\'를 만나 사랑에 빠지게 된다. 행복한 결혼식을 올린 두 사람은 막심의 저택인 맨덜리에서 함께 생활하게 되는데..','2023-05-01 14:20:21','보냅니다...','성남아트센터',32,'Qma8cw8HTz99x5kr591YnqLhvpcGKTvT8yBeZcciZ4xwg5',0.02,'2023-04-03 14:00:00','레베카','0xe1CBC454A1f511Ece02ACb690b534310c5C8c1A8'),(17,'대한 제국의 주권이 일본에 완전히 빼앗길 위기에 놓인 1909년. 갓 서른 살의 조선 청년 안중근은 러시아 연주의 자작나무 숲에서 동지들과 단지(斷指) 동맹으로써 독립운동의 결의를 다진다. 명성황후 시해 당시 어린 궁녀로서 그 참상을 목격해야 했던 설희는 김 내관에게 독립운동에 투신할 뜻을 밝힌다.','2023-04-14 13:45:00','보냅니다...','블루스퀘어 신한카드몰',40,'QmUjv2TCbGD46A1SqBo2qPNfXrr9PqLY2A6EcfnVMFYtuZ',0.02,'2023-04-10 14:24:58','영웅','0xe1CBC454A1f511Ece02ACb690b534310c5C8c1A8'),(18,'화려한 빛과 색으로 기쁨과 환희를 노래하는 \'뒤피\'의 원화 130여점 공개!','2023-04-08 14:00:00','보냅니다...','더현대 서울 6층 ',40,'QmRm2Dm3o9Up3x3o3d5nXcFZe8wrQsew3qmMaj9sGnhRXT',0.001,'2023-04-05 14:00:00','더현대서울 프랑스국립현대미술관전 : 라울 뒤피','0x3C4Bc302dcA1Ba566F57929D3a9ceB031901C897'),(19,'에픽하이 콘서트','2023-04-05 14:58:00','보냅니다...',' SHOWBOX SODO',8,'QmTKeTJDdo8HNYi8ctv3kYu8sLDDFVq6wDc9WH2pCiiY8f',0.005,'2023-04-02 14:55:30','에픽하이 공연','0xe1CBC454A1f511Ece02ACb690b534310c5C8c1A8'),(20,'공연시간 정보\n예매가능시간: 관람 2시간 전까지\n\n평일 20시 / 주말 및 공휴일 14시, 18시 *월요일 공연 없음','2023-04-05 16:30:00','보냅니다...','coex 신한카드 artium',8,'QmZNB2zkPssxNS8MqXGkkBZPR36s5zkbKRBgUZiNAdBjzr',0.02,'2023-04-05 14:00:00','식스 더 뮤지컬 최초 한국 공연 - 한국어','0x185E4d107F37ec094315C29b12E83cdE2b2C44E4'),(21,'일본에서 난리난 아이묭을 보러 날아가도록 하자.','2023-04-05 20:00:00','보냅니다...','TOKYO',48,'QmdPjUm5YdwggCK9BZLeNgSMDKrqHfDAju34uB9s9SxZJE',0.005,'2023-04-01 18:00:00','아이묭 콘서트','0xb73ECfa6251D47e1236A8c89f26D4cc3Dd65C70d'),(22,'주말좌 위켄드 형님이 공연을 하신다. LA여행을 간다면 꼭 참여하도록 하자.','2023-04-05 22:00:00','보냅니다...','LA',40,'QmPL1nx8kFK6JF7H2NctYfcA92YgBGnVP1tDAoXyk4XEMo',0.002,'2023-04-03 20:00:00','Weekend AFTER HOURS','0xb73ECfa6251D47e1236A8c89f26D4cc3Dd65C70d'),(23,'빈지노 사랑하는 도시 대전에 뜬다. ','2023-04-05 17:00:00','보냅니다...','대전 파이낸스홀',40,'QmQYvzd3pgc8P6anbcMbhLFoujgw7M7sw5C1yHfuLuCSiY',0.004,'2023-04-02 21:00:00','Beenzino I\'M BACK','0xb73ECfa6251D47e1236A8c89f26D4cc3Dd65C70d'),(24,'검정치마 3집 part.2 앨범 투어. 이번엔 부산이다!','2023-04-05 21:00:00','보냅니다...','부산',48,'QmYumbHDy9PES3Rs31rDkwjBvH2qfdC6F1jHUPKtz6vwAV',0.03,'2023-04-02 15:00:00','검정치마 THIRSTY 콘서트 - 부산','0xb73ECfa6251D47e1236A8c89f26D4cc3Dd65C70d'),(25,'250여년을 초월한 베토벤의 위대한 음악이 현대적인 감성과 만나 뮤지컬로 재탄생한 혁명적인 작품!','2023-04-11 16:00:00','보냅니다...','세종문화회관 대극장',40,'QmNnmfJTfEsj2ouGxg3RkFY1QwmSdHMjbLX7s7jq29HET8',0.0004,'2023-04-06 12:00:00','뮤지컬 〈베토벤; Beethoven Secret〉 SEASON 2','0x3C4Bc302dcA1Ba566F57929D3a9ceB031901C897'),(26,'전설의 밴드 오아시스가 첫 내한 공연을 한다!!','2023-04-06 19:00:00','보냅니다...','올림픽공원',40,'QmVD5sj3yQZMERDo6TAgaVwoM9KFRvAEKnXznwL1nhNGiV',0.05,'2023-04-02 17:00:00','Oasis 대망의 첫 내한 공연','0xb73ECfa6251D47e1236A8c89f26D4cc3Dd65C70d'),(27,'빈지노가 봄 맞이 라이브 공연을 한다!','2023-04-06 20:00:00','보냅니다...','한남 블루스퀘어',24,'QmdVNhHg21X1CWKK1brq1rEpCd659EDPTdSJRThPjVScd3',0.03,'2023-04-01 12:00:00','빈지노 Spring HIPHOP Live','0xb73ECfa6251D47e1236A8c89f26D4cc3Dd65C70d'),(28,'대한민국 명실상부 최고의 3인조 밴드 자우림이 올림픽공원에서 공연을 한다!!','2023-04-08 19:00:00','보냅니다...','올림픽공원 올림픽홀',24,'QmQVsNGfSufwfYWdse8RRYTMwTWTbW64zGruVJpjNKzG1z',0.05,'2023-03-31 18:00:00','자우림 콘서트','0x5248E71ec4A6cdE490000f4356b67b6f90aa62B8'),(29,'크러쉬가 첫 단독 공연을 한다. 다양한 게스트가 준비되어 있다고 한다!!','2023-04-08 21:00:00','보냅니다...','잠실종합경기장',24,'QmcTXp1rDSQJF2Sf4dmXUdszkCy3hBZPNeYoHdF3Yvm5tU',0.08,'2023-04-01 12:00:00','CRUSH HOUR','0x5248E71ec4A6cdE490000f4356b67b6f90aa62B8');
/*!40000 ALTER TABLE `performance` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-06 15:14:02
